<?php

namespace Magenmagic\AgeVerification\Block\Customer;

use Magenmagic\AgeVerification\Helper\Data;
use Magento\Backend\Block\Template;
use Magento\Backend\Block\Template\Context;
use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Customer\Model\Session;

/**
 * @category   Magenmagic
 * @package    Magenmagic_AgeVerification
 * @author     Alex Brynov
 */
class Tag extends Template
{
    /**
     * @var Session|null
     */
    private $customerSession;

    /**
     * @var CustomerRepositoryInterface
     */
    private $repository;

    /**
     * @var Data
     */
    private $helper;

    /**
     * @param Context                     $context
     * @param Session                     $customerSession
     * @param CustomerRepositoryInterface $repository
     * @param Data                        $helper
     * @param array                       $data
     */
    public function __construct(
        Context $context,
        Session $customerSession,
        CustomerRepositoryInterface $repository,
        Data $helper,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->customerSession = $customerSession;
        $this->repository      = $repository;
        $this->helper          = $helper;
    }

    /**
     * @return string
     */
    public function getTag()
    {
        $value = $this->repository->getById($this->customerSession->getId())->getCustomAttribute(
            Data::ATTRIBUTE_CODE_VERIFIED
        )->getValue();

        return $value ? $this->helper->getTagVerified() : $this->helper->getTagNotVerified();
    }
}
