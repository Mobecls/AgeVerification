<?php

namespace Magenmagic\AgeVerification\Helper;

use Magento\Contact\Model\ConfigInterface;
use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\App\Helper\Context;
use Magento\Framework\Encryption\EncryptorInterface;

/**
 * @category   Magenmagic
 * @package    Magenmagic_AgeVerification
 * @author     Alex Brynov
 */
class Data extends AbstractHelper
{
    /**
     * Path for "Enable module" setting
     */
    const XML_PATH_ENABLE = 'magenmagic_age_verification/general/enabled';

    /**
     * Path for "API username" setting
     */
    const XML_PATH_API_USERNAME = 'magenmagic_age_verification/api/username';

    /**
     * Path for "API password" setting
     */
    const XML_PATH_API_PASSWORD = 'magenmagic_age_verification/api/password';

    /**
     * Path for "Tag Verified" setting
     */
    const XML_PATH_TAG_VERIFIED = 'magenmagic_age_verification/frontend/tag_verified';

    /**
     * Path for "Tag Not Verified" setting
     */
    const XML_PATH_TAG_NOT_VERIFIED = 'magenmagic_age_verification/frontend/tag_not_verified';

    /**
     * Path for "Recipient Email" setting
     */
    const XML_PATH_EMAIL_RECIPIENT_EMAIL = 'magenmagic_age_verification/email/recipient_email';

    /**
     * ID of email verification template
     */
    const EMAIL_TEMPLATE_VERIFICATION_REQUEST = 'magenmagic_age_verification_request';

    /**
     * Customer EAV attribute for verified flag
     */
    const ATTRIBUTE_CODE_VERIFIED = 'mm_age_is_verified';

    /**
     * @var EncryptorInterface
     */
    protected $encryptor;

    /**
     * @var ConfigInterface
     */
    protected $contactsConfig;

    /**
     * @param Context            $context
     * @param EncryptorInterface $encryptor
     * @param ConfigInterface    $contactsConfig
     */
    public function __construct(
        Context $context,
        EncryptorInterface $encryptor,
        ConfigInterface $contactsConfig
    ) {
        $this->encryptor      = $encryptor;
        $this->contactsConfig = $contactsConfig;
        parent::__construct($context);
    }

    /**
     * @return bool
     */
    public function isEnabled()
    {
        return (bool)$this->scopeConfig->getValue(self::XML_PATH_ENABLE);
    }

    /**
     * @return string
     */
    public function getApiUsername()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_API_USERNAME);
    }

    /**
     * @return string
     */
    public function getApiPassword()
    {
        return $this->encryptor->decrypt($this->scopeConfig->getValue(self::XML_PATH_API_PASSWORD));
    }

    /**
     * @return string
     */
    public function getTagVerified()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_TAG_VERIFIED);
    }

    /**
     * @return string
     */
    public function getTagNotVerified()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_TAG_NOT_VERIFIED);
    }

    /**
     * @return string
     */
    public function getRecipientEmail()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_EMAIL_RECIPIENT_EMAIL)
            ?: $this->contactsConfig->emailRecipient();
    }
}