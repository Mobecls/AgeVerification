<?php

namespace Magenmagic\AgeVerification\Observer\Customer;

use Magenmagic\AgeVerification\Helper\Data;
use Magento\Customer\Api\Data\CustomerInterface;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\UrlInterface;
use Magento\Customer\Model\Session;

/**
 * @category   Magenmagic
 * @package    Magenmagic_AgeVerification
 * @author     Alex Brynov <lexpochta@gmail.com>
 */
class Login implements ObserverInterface
{
    /**
     * @var UrlInterface
     */
    private $url;

    /**
     * @var Session
     */
    private $session;

    /**
     * @var Data
     */
    private $helper;

    /**
     * Login constructor.
     *
     * @param UrlInterface $url
     * @param Session      $session
     * @param Data         $helper
     */
    public function __construct(
        UrlInterface $url,
        Session $session,
        Data $helper
    ) {
        $this->url     = $url;
        $this->session = $session;
        $this->helper  = $helper;
    }

    /**
     * @param Observer $observer
     */
    public function execute(Observer $observer)
    {
        if (!$this->helper->isEnabled()) {
            return;
        }

        /** @var CustomerInterface $customer */
        $customer = $observer->getEvent()->getCustomer();

        $redirectUrl = null;
        $isVerified  = $customer->getData(Data::ATTRIBUTE_CODE_VERIFIED);

        // Customer did not submit verification request, redirect him to page with verification form
        if ($isVerified === null) {
            $redirectUrl = 'magenmagic_ageverification';
        } elseif (!$isVerified) {
            $redirectUrl = 'magenmagic_ageverification/documents';
        }

        if ($redirectUrl) {
            $this->session->setBeforeAuthUrl($this->url->getUrl($redirectUrl));
        }
    }
}
