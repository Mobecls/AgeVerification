<?php

namespace Magenmagic\AgeVerification\Setup;

use Magenmagic\AgeVerification\Helper\Data;
use Magento\Customer\Model\Customer;
use Magento\Customer\Setup\CustomerSetup;
use Magento\Customer\Setup\CustomerSetupFactory;
use Magento\Framework\Setup\InstallDataInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;

/**
 * @category   Magenmagic
 * @package    Magenmagic_AgeVerification
 * @author     Alex Brynov
 *
 * @codeCoverageIgnore
 */
class InstallData implements InstallDataInterface
{
    /**
     * Customer setup factory
     *
     * @var CustomerSetupFactory
     */
    private $customerSetupFactory;

    /**
     * Init
     *
     * @param CustomerSetupFactory $customerSetupFactory
     */
    public function __construct(CustomerSetupFactory $customerSetupFactory)
    {
        $this->customerSetupFactory = $customerSetupFactory;
    }

    /**
     * {@inheritdoc}
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    public function install(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {
        /** @var CustomerSetup $customerSetup */
        $customerSetup = $this->customerSetupFactory->create(['setup' => $setup]);

        $setup->startSetup();

        /**
         * Due to known bug, it is not possible for now to add custom attribute to grid
         * https://github.com/magento/magento2/issues/10838
         */
        $customerSetup->addAttribute(
            Customer::ENTITY,
            Data::ATTRIBUTE_CODE_VERIFIED,
            [
                'label'           => 'Age Is Verified',
                'type'            => 'int',
                'input'           => 'select',
                'position'        => 140,
                'visible'         => true,
                'required'        => false,
                'system'          => false,
                'source'          => \Magento\Eav\Model\Entity\Attribute\Source\Boolean::class,
                'default'         => 0,
                //'is_used_in_grid' => true,
            ]
        );

        $customerSetup->getEavConfig()->getAttribute(Customer::ENTITY, Data::ATTRIBUTE_CODE_VERIFIED)
            ->setData('used_in_forms', ['adminhtml_customer'])
            ->save();

        $setup->endSetup();
    }
}
